import axios from "axios";
import { config } from "../config/env.js";

/**
 * Fetch current holdings
 */
export async function getHoldings() {
  try {
    const response = await axios.get(`${config.GROWW_BASE_URL}/order/list`, {
      headers: {
        "Accept": "application/json",
        "Authorization": `Bearer ${config.GROWW_ACCESS_TOKEN}`,
        "X-API-VERSION" : "1.0"
      }
    });
    console.log("📈 Current holdings fetched successfully:", response.data);
    return response.data;
  } catch (err) {
    console.error("❌ Error fetching holdings:", err.response?.data || err.message);
    throw err;
  }
}

/**
 * Place a new order
 * @param {Object} orderData - Order details
 */
export async function placeOrder(orderData) {
  const response = await axios.post(`${config.GROWW_BASE_URL}/order`, orderData, {
    headers: {
      "Accept": "application/json",
      "Authorization": `Bearer ${config.GROWW_ACCESS_TOKEN}`,
      "X-API-VERSION" : "1.0"
    }
  });
  return response.data;
}
