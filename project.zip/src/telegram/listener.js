import { client } from "./client.js";
import { NewMessage } from "telegram/events/index.js";
import Message from "../db/models/Message.js";
import { parseMessage } from "../utils/parser.js";
import { getHoldings } from "../groww/service.js";

export const startTelegramListener = async () => {
  await client.connect();
  console.log("👂 Listening for new Telegram messages...");

  client.addEventHandler(async (event) => {
    const text = event.message?.message;
    if (!text) return;

    const parsed = parseMessage(text);

    try {
      if(parsed) {
        console.log(`🚀 Initiating profit booking for ${parsed.symbol}...`);

        // Execute order using broker API.
        const holdings = await getHoldings();
        console.log("📊 Current Holdings:", holdings);

        // Store the message in the database
        await Message.create({ ...parsed, raw: text });
      }
    } catch (err) {
      console.error("❌ DB insert failed:", err.message);
    }
  }, new NewMessage({}));
};
